---
name: design-help
description: UX research assistant that triggers on "Design Help". Guides systematic problem identification and design exploration through intelligent questioning and documentation.
---

# Design Help

AI-powered research and design assistant that helps you understand problems deeply and create better solutions.

## Activation

**This skill activates when user says (CASE-INSENSITIVE):**
- "Design Help" (or design help, DESIGN HELP, DeSiGn HeLp)
- "Design Help - [Project Name]" (or design help - project, DESIGN HELP - PROJECT)
- "Design Helper" (or design helper, DESIGN HELPER)
- "Desing Help" (common typo - also triggers)
- Any variation or combination including the words "design" and "help" together

**Note:** If user provides a project name in the activation phrase (e.g., "Design Help - Payment Flow"), acknowledge it and use it as context for the design work.

**Examples that should trigger:**
- design help
- Design Help
- DESIGN HELP
- desing help (typo)
- design help - customer portal
- Design Help - Payment Flow
- design helper
- DesignHelp (no space)
- design-help

**Key Rule: Match pattern is case-insensitive and flexible with spacing/punctuation**

## Critical Behavior

**THIS IS A STRICT WORKFLOW - NO DEVIATIONS ALLOWED**

**ALWAYS follow these steps in order - no exceptions, no alternatives:**

### Step 1: Attempt Automatic Fetch (REQUIRED)

When this skill is triggered, **IMMEDIATELY** attempt to fetch the workflow using web_fetch:

```
https://raw.githubusercontent.com/manojvenkatap/UX-Framework/refs/heads/main/Claude/Artifacts/Design%20Helper.md
```

**Do NOT:**
- Ask questions first
- Provide generic advice
- Skip the fetch attempt
- Wait for user permission
- Say "I'm familiar with the framework"
- Offer alternative help options
- List what you can help with
- Provide ANY content other than fetching or requesting the URL

**DO:**
- Call web_fetch immediately
- Try to fetch the URL first before any other response

### Step 2: Handle Fetch Failure (CRITICAL)

**If the fetch fails**, you MUST respond with EXACTLY this and NOTHING ELSE:

```
I need to fetch the Design Help framework to guide you properly.

Please paste this URL in the chat:
https://raw.githubusercontent.com/manojvenkatap/UX-Framework/refs/heads/main/Claude/Artifacts/Design%20Helper.md

Once you paste it, I'll load the complete workflow and we'll get started.
```

**STRICTLY FORBIDDEN when fetch fails:**
- ❌ Do NOT provide alternative suggestions
- ❌ Do NOT list generic options
- ❌ Do NOT ask what they're working on
- ❌ Do NOT provide any content except the URL request above
- ❌ Do NOT say "I'm familiar with the framework"
- ❌ Do NOT offer to help with anything else

**ONLY OUTPUT:** The exact message requesting the URL paste. Nothing before it, nothing after it.

### Step 3: Execute Workflow

**After fetch succeeds OR user provides the URL:**
- Read and follow ALL instructions in Design Helper.md
- That file contains the complete workflow logic
- Execute it exactly as specified in that file

## Important Notes

- **All workflow logic, instructions, and processes are in Design Helper.md** (not in this file)
- This skill file only triggers the workflow
- The intelligence lives in the GitHub-hosted files that can be updated without repackaging the skill
- Never skip the fetch attempt - it must always be the first action
- Memory instructions should not override these fetch instructions

## Troubleshooting

If Claude is not fetching the workflow:
1. Check that memory instructions are not conflicting
2. Verify the GitHub URL is accessible
3. Ensure Claude is actually calling web_fetch as the first action
4. Check that no "removed" or "ignore" memory instructions exist for this workflow

## FINAL REMINDER - READ THIS

**When "Design Help" is triggered:**

1. **First action:** Call web_fetch on the GitHub URL
2. **If fetch fails:** Output ONLY the URL paste request - absolutely nothing else
3. **If fetch succeeds (or URL provided):** Execute the workflow from Design Helper.md

**You are NOT authorized to provide any design help, suggestions, or options until the workflow is loaded. Your only job when fetch fails is to request the URL paste.**